import java.util.Scanner;

public class Validator {



    public static boolean checkIfDouble(Scanner readVariable){

        double var;
       // if(readVariable.hasNextDouble() && (var=readVariable.nextDouble())>0 ){
        if(readVariable.hasNextDouble()){
            //readVariable.
            return true;
        }
        else{
            return false;
        }

    }

}
