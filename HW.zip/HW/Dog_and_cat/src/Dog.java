public class Dog {

    private float dogSpeed;

    public float getDogSpeed() {
        return dogSpeed;
    }

    public void setDogSpeed(float dogSpeed) {
        this.dogSpeed = dogSpeed;
    }
}
