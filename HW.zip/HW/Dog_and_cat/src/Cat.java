public class Cat {
    private float catSpeed;

    public float getCatSpeed() {
        return catSpeed;
    }

    public void setCatSpeed(float catSpeed) {
        this.catSpeed = catSpeed;
    }
}
